<template>
    <div>

    </div>
</template>

<script>
export default {
    data(){
        return {}
    },
    created(){
        console.log(this.$route.query.nid);
    },methods:{
        
    }
}
</script>

<style>

</style>